% tic
% D1 = 3;
% D2 = 4;
% D3 = 100;
% A = [D1,D2,D3];
% [D,I] = min(A);
% toc

% tic
% D1 = 3;
% D2 = 4;
% D3 = 100;
% if D1 < D2 && D1 < D3
%     D = 1;
%     I = 1;
% elseif D2 < D1 && D2 < D3
%     D = 2;
%     I = 2;
% elseif D3 < D1 && D3 < D2
%     D = 3;
%     I = 3;    
% end
% toc